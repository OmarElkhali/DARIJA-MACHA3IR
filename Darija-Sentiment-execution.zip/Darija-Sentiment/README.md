# Darija-Sentiment · notebook autonome A–G

Le [notebook principal](notebooks/TP2_Darija.ipynb) est **préparé, non exécuté** : 49 cellules de code,
avec explications, tableaux et graphiques qui utiliseront vos futures mesures. Aucun nouveau gain n'est revendiqué.
Le marocain `ary` reste la tâche principale ; `arq/train` intervient **uniquement dans E2**.

Les sorties de votre exécution interrompue sont conservées dans
[TP2_Darija_observe_avant_v4.ipynb](notebooks/TP2_Darija_observe_avant_v4.ipynb).
Une sauvegarde locale complète et vérifiée précède les modifications. Voir
[la migration v4](research/migration_v4.md) pour ses limites et la sauvegarde des poids encore sur Colab.

## Exécuter vous-même

1. Importer le notebook corrigé sur Kaggle/Colab, ou l'ouvrir localement avec Python 3.10–3.13.
2. Lire les options au tout début de la première cellule : `DEVICE`, `ARAVEC_PATH`, `CONFIG_OVERRIDES`.
3. Exécuter les cellules dans l'ordre. `RUN_TRAINING=True` et `RUN_FINAL_EVALUATION=True` sont prêts
   pour votre exécution complète. Aucun de ces entraînements n'a été lancé lors de la préparation.
4. Si des bibliothèques déjà chargées sont mises à jour, redémarrer le kernel une fois puis reprendre au début.
5. Après F/G, compléter les revues humaines dans `OUTPUT/results/` et `OUTPUT/human_review/`.

Pour diagnostiquer le démarrage, exécuter séparément les cellules **1.1 Options**, **1.2 Archive**,
**1.3 Projet**, **1.4 Sauvegarde Drive**, **1.5 Résultats**, puis **1.6 Dépendances**.
Dans la session Colab existante, exécuter 1.1–1.4 avant de redémarrer pour copier les anciens poids
et résultats sur Drive. Le montage exige votre autorisation interactive. La cellule 1.6 installe
les dépendances. Le nouveau `CAMPAIGN_NAME=campaign_v4` protège les anciennes mesures.

Le code et les données ary sont intégrés au notebook : le dossier `src/` peut être restauré automatiquement
si vous importez uniquement le fichier `.ipynb`. Les dossiers en lecture seule sont copiés vers un espace
de travail inscriptible. Les dépendances sont vérifiées avant les imports scientifiques ;
`INSTALL_DEPENDENCIES=True` installe celles qui manquent ou sont incompatibles, sans remplacer un PyTorch
GPU déjà compatible. `AUTO_DOWNLOAD_ARAVEC=True` récupère les trois fichiers officiels si nécessaire et
vérifie leurs SHA-256. Les données, AraVec, les imports et l'accès aux configurations des modèles sont
contrôlés avant A. Cela ne valide pas à l'avance la mémoire GPU de chaque entraînement ni tous les poids.
Sous Python 3.10–3.13, Gensim 4.4 accepte NumPy 1 ou 2 : le notebook conserve les versions
compatibles de NumPy, SciPy et PyTorch du runtime. Le rapport pip permet de demander un redémarrage
uniquement si une bibliothèque déjà chargée a été remplacée, y compris une dépendance transitive.
Dans ce cas, réexécuter la cellule seule reste bloqué jusqu'au redémarrage du kernel.
Les versions compatibles de pandas, Matplotlib, SentencePiece, Protobuf, psutil et IPython
sont également conservées : aucun épinglage spécial Python 3.13 ne les remplace inutilement.
CUDA est recommandé pour E. `micro_batch_e=2` s'accumule en batch effectif 32 ; l'installation PyTorch
doit correspondre à votre GPU. Prévoir du stockage pour E1/E2 et les neuf adaptations de nettoyage P,
ainsi que le checkpoint de reprise du run actif (modèle, meilleur modèle et états d'optimiseur).
Un essai court avec les vrais poids est activé par `RUN_SMOKE_TEST=True` dans Colab.

```powershell
& 'C:\Users\SetupGame\anaconda3\python.exe' -m jupyter notebook notebooks/TP2_Darija.ipynb
```

Le HTML principal est un aperçu **sans sorties**. `python scripts/build_notebook.py` régénère le notebook
sans l'exécuter. Ne pas utiliser `scripts/execute_notebook.py` pour une simple prévisualisation : il exécute
les cellules, donc les entraînements activés dans la configuration.

## Importer uniquement le notebook

La version corrigée incorpore une archive vérifiée du code et des petits fichiers de données. Il suffit
d'importer **le nouveau** `TP2_Darija.ipynb` puis d'exécuter les cellules dans l'ordre, avec Internet activé
pour les ressources externes absentes. Les anciens notebooks téléchargés ne bénéficient pas de ce correctif.

Le ZIP reste disponible comme alternative si vous préférez voir et modifier les fichiers séparément.

Importer **Darija-Sentiment-execution.zip**, puis l'extraire dans un dossier inscriptible :

```python
from pathlib import Path
from zipfile import ZipFile

ARCHIVE = Path("/chemin/vers/Darija-Sentiment-execution.zip")  # Adapter à votre fichier importé.
DESTINATION = Path("/kaggle/working")  # Ou /content sur Colab.
with ZipFile(ARCHIVE) as archive:
    archive.extractall(DESTINATION)  # Archive du projet fournie ici.
```

Dans la première cellule du notebook, définir au besoin :

```python
PROJECT_DIR = "/kaggle/working/Darija-Sentiment"  # Ou /content/Darija-Sentiment.
```

Le notebook détecte aussi les projets dans les dossiers courants de Kaggle/Colab, avec une recherche
limitée en profondeur. Plusieurs copies exigent un choix explicite. L'archive légère ne contient pas
les poids AraVec ni les modèles historiques : leur téléchargement se fait lorsque vous exécutez le notebook.
Si AraVec est déjà monté dans un dataset, renseigner `ARAVEC_PATH` au début de la première cellule.
Pour une exécution hors ligne, fournir aussi les modèles dans le cache Hugging Face et désactiver
`CHECK_MODEL_ACCESS` ; les poids manquants ne seront jamais remplacés par un modèle différent.

## Couverture préparée

| Partie | Expériences |
|---|---|
| A | Distributions globales/par écriture ; majorité ; règle script-only ; TF-IDF mots 1–2, caractères 2–5 et union ; LR balanced ; C=0.25/1/4 pour union ; décision val |
| B | NLI imposé, hypothèses ar/fr/en ; CAMeLBERT ; scores val/test de chaque variante et décomposition par écriture |
| C | Vocabulaire train fréquence ≥2 ; C1–C4 ; Transformer 2 couches/128D/4 têtes ± positions ; AraVec/fastText ; OOV par écriture |
| Déséquilibre | Meilleurs architecture ET embeddings C choisis sur val ; témoin/perte pondérée/suréchantillonnage train, avec et sans décision val |
| D | DarijaBERT gelé CLS/mean+LR et états+BiLSTM-attention ; cinq exemples d'attention C et D |
| E1 | Deux DarijaBERT fine-tunés, perte pondérée, AdamW 2e-5, batch 32, 3–5 époques, warmup 10 %, early stopping, trois graines |
| E2 | Encodeur E1 choisi sur val ; têtes ary/arq ; L_ary + λ L_arq ; λ=0 référence E1, puis 0.1/0.3/0.7 ; aucun test arq |
| F1 | Distributions val/test ; décision val figée ; grille F1/décalages et oracle test strictement diagnostique |
| P | Quatre nettoyages TF-IDF/DarijaBERT ; emojis seuls et ponctuation seule comme diagnostics ; référence BERT conservatrice réutilisée depuis E1 |
| F2–F3 | Arabe→latin et inversement avec TF-IDF union déterministe ; témoin train complet ; scores par classe, écriture, présence d'emojis |
| F4 | Retrait séparé/conjoint emojis et ponctuation sur la même population ; bascules ; métriques à labels originaux explicitement diagnostiques et revue humaine persistante |
| F5 | Trois graines pour modèles entraînés ; bootstrap 1 000/IC 95 % ; McNemar entre deux variantes choisies sur val |
| F6 | Trente erreurs, catégories proposées et votes disponibles ; colonnes humaines conservées lors des relances |
| G | Qualité, robustesse, temps, coûts partagés, latence CPU, poids, paramètres et matrice du candidat fixé sur val |
| F7 | Tests linguistiques construits à annoter et gabarit vide pour nouveaux textes indépendants ; seuls les labels réellement validés sont évalués |

`comparison_all_variants.csv` détaille ces mesures pour chaque variante représentative ;
`comparison.csv` conserve le résumé des cinq familles retenues sur val.

Les options MARBERTv2, translittération et cibles souples ne sont pas incluses. F4 n'isole pas l'effet du
français, des chiffres Arabizi et des lettres répétées ; aucune ablation de ces indices n'est revendiquée.
Les [questions officielles Q1–Q12](research/questions_officielles.md) sont intégrées au parcours d'oral.

## Modifications visant un meilleur résultat

- Nettoyage conservateur : retirer mentions/URLs, conserver négation, emojis, accents, chiffres et répétitions.
- TF-IDF mots conserve les symboles ; régularisation comparée sur val.
- C : maximum 15 époques avec early stopping, 128 tokens ou 512 caractères pour C4.
- FastText compose les vecteurs des UNK par sous-mots, sans apprendre de vocabulaire sur val/test.
- D/E : 128 sous-tokens ; D2 jusqu'à 10 époques ; E jusqu'à 5, précision mixte CUDA et checkpointing.
- E distingue le temps de préparation/chargement (`setup_seconds`) de la boucle d'apprentissage.
- Perte pondérée normalisée sur le batch effectif ; E2 accompagne chaque pas ary d'un lot arq.

Ces changements sont des hypothèses à mesurer. **Le test ary a déjà été observé dans l'étude historique** :
la nouvelle campagne est exploratoire, même si aucun réglage automatique n'utilise ses labels.
Une confirmation indépendante demande de nouveaux exemples annotés.

## Reprise et historique

Les nouvelles sorties vont dans `experiments/campaign_v4/`, sur Drive dans Colab par défaut. Configuration, révision des données et hashes
du code sont figés au démarrage. Un changement exige un nouveau `CAMPAIGN_NAME`. Un run terminé est
réutilisé ; les réseaux interrompus reprennent après la dernière époque terminée. Les données et
hyperparamètres doivent correspondre au checkpoint. Une époque interrompue recommence ; les états
aléatoires, optimiseur, scheduler, scaler et meilleur modèle sont restaurés. Le checkpoint de reprise
est remplacé par le checkpoint final à la réussite. Les durées reprises incluent les époques terminées
précédemment ; le travail perdu au milieu d'une époque n'est pas reconstitué.
Le test n'est ouvert que si toutes les expériences requises sont terminées et les choix verrouillés.

Les anciens `results/` et `models/` sont conservés, ainsi que le
[notebook historique](notebooks/TP2_Darija_historique.ipynb) et son
[README](README_historique.md). L'application et le PPTX continuent de présenter ces anciennes mesures ;
ils ne sont pas automatiquement actualisés par cette refonte.

## Vérification locale

```powershell
python tests/check_campaign.py
python tests/check_notebook_setup.py
python tests/check_improvements.py
python -m src.smoke
```

Les deux premiers contrôles vérifient plans, garde-fous, analyses et amorçage avec pip/réseau simulés.
`check_improvements.py` entraîne un petit réseau synthétique pour vérifier la reprise après interruption.
Les performances du benchmark, la mémoire GPU et l'exécution complète restent à vérifier dans la campagne.

Le contrôle d'amorçage simule aussi pip et les ressources réseau, vérifie la restauration d'un notebook seul,
les dossiers en lecture seule, les archives invalides et les fichiers incomplets. La configuration se fige
seulement après les vérifications initiales ; les marqueurs de runs interrompus autorisent leur reprise
depuis la dernière époque sauvegardée pour les réseaux. Le cache D2 est mappé sur disque ; fichiers,
masques et dimensions sont vérifiés et une extraction incomplète est reconstruite.

`python -m src.smoke` exécute de petits entraînements temporaires avec des encodeurs minuscules
aléatoires pour tester la sérialisation ; ses scores ne sont pas des résultats de recherche.
`python -m src.smoke --real-pretrained --device cuda` utilise les poids officiels sur un petit
sous-ensemble : à exécuter dans l'environnement T4, pas une preuve de performance sur le benchmark complet.
